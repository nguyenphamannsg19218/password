# File: getcid.py

import sys
import asyncio
import random
import time
from telethon import TelegramClient
from telethon import events
from decimal import Decimal
import getpass
import requests
import os

api_id = '21779358'
api_hash = 'f6458e9bcf1d1e97088dc8ea1ef9106b'

# Function to fetch the password from a raw link
def fetch_password(url):
    try:
        response = requests.get(url)
        response.raise_for_status()
        return response.text.strip()
    except requests.RequestException as e:
        print(f"Error fetching password: {e}")
        sys.exit(1)

# Function to check if the device is blocked
def is_device_blocked():
    device_name = os.getenv('COMPUTERNAME')
    try:
        with open(r"C:\Users\Public\Documents\blocked_devices.txt", "r") as f:
            blocked_devices = f.read().splitlines()
            if device_name in blocked_devices:
                return True
    except FileNotFoundError:
        pass  # File not found is okay, means no devices are blocked yet
    return False

# Function to block the device
def block_device():
    device_name = os.getenv('COMPUTERNAME')
    with open(r"C:\Users\Public\Documents\blocked_devices.txt", "a") as f:
        f.write(f"{device_name}\n")

async def main():
    if is_device_blocked():
        print("This device is blocked from using this script.")
        return

    # Secure password input
    password = getpass.getpass(prompt="Enter your password: ")

    # URL to fetch the password (this should be replaced with the actual URL)
    password_url = "https://nguyenphamannsg19218.github.io/password/password.txt"
    correct_password = fetch_password(password_url)

    # Check if the input password matches the fetched password
    if password != correct_password:
        print("Incorrect password. Blocking this device.")
        block_device()
        return

    if len(sys.argv) != 2 or not sys.argv[1].replace('-', '').replace(' ', '').isdigit() or len(sys.argv[1].replace('-', '').replace(' ', '')) not in [54, 63]:
        print("Invalid input. Please provide a 54 or 63-digit number.")
        return
    
    input_sequence = sys.argv[1].replace('-', '').replace(' ', '')
    client = TelegramClient('session', api_id, api_hash)
    await client.start()
    
    print("Connecting to Microsoft Server...")
    await asyncio.sleep(random.randint(1, 5))
    print("Performing dialing...")
    await asyncio.sleep(random.randint(1, 5))
    print("Please wait, we are entering the verification code from the Microsoft bot reading..")
    await asyncio.sleep(random.randint(1, 5))
    print("Successfully authenticated..")
    await asyncio.sleep(random.randint(1, 5))
    print("Please wait, we are sending IID to Microsoft..")
    await asyncio.sleep(random.randint(1, 5))
    
    if client.is_connected():
        await client.send_message('@laomms', input_sequence)
        client.start_time = time.time()  # Use client object to store start time

        @client.on(events.NewMessage(chats='@laomms'))
        async def handler(event):
            message = event.message.message
            if "IID:" in message and "CID:" in message:
                data = message.split('\n')
                for index, line in enumerate(data):
                    if "Time consuming:" in line or "CID:" in line:
                        print("\n".join(data[:index + 1 if "Time consuming:" in line else index + 2]))
                        break
            end_time = time.time()  # Record the time just before disconnecting
            elapsed_time = end_time - client.start_time  # Calculate the elapsed time using client.start_time
            rounded_time = round(elapsed_time, 2)  # Round to two decimal places

            # Subtract 8 seconds and handle negative time
            adjusted_time = rounded_time - 10
            if adjusted_time < 0:
                print(f"Time taken: {rounded_time:.2f} seconds")  # Ensure two decimal places
            else:
                print(f"Time taken: {adjusted_time:.2f} seconds")  # Ensure two decimal places
            await client.disconnect()
        await client.run_until_disconnected()

if __name__ == '__main__':
    asyncio.run(main())
